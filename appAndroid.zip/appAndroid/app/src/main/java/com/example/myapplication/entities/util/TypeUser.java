package com.example.myapplication.entities.util;

public enum TypeUser {
    LeaderBiker, Biker;
}